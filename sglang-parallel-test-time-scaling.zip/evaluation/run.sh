# python evaluation/main.py > temp.log 2>&1 &

# nohup sh evaluation/suite_baseline.sh > suite_baseline.log 2>&1 &
# nohup sh evaluation/suite_conformal.sh > suite_conformal.log 2>&1 &
# nohup sh evaluation/suite_asycn.sh > suite_asycn.log 2>&1 &